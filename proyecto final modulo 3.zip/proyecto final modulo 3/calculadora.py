import math


# Función para mostrar la calculadora avanzada
def calculadora_avanzada():
    print("Calculadora avanzada:")
    print("1. Suma")
    print("2. Resta")
    print("3. Multiplicación")
    print("4. División")
    print("5. Raíz cuadrada")
    print("6. Potenciación")
    print("7. Coseno")
    print("8. Salir")

    opcion = input("Selecciona una opción (1-8): ")

    if opcion == "1":
        num1 = float(input("Introduce el primer número: "))
        num2 = float(input("Introduce el segundo número: "))
        print(f"Resultado: {num1 + num2}")
    elif opcion == "2":
        num1 = float(input("Introduce el primer número: "))
        num2 = float(input("Introduce el segundo número: "))
        print(f"Resultado: {num1 - num2}")
    elif opcion == "3":
        num1 = float(input("Introduce el primer número: "))
        num2 = float(input("Introduce el segundo número: "))
        print(f"Resultado: {num1 * num2}")
    elif opcion == "4":
        num1 = float(input("Introduce el primer número: "))
        num2 = float(input("Introduce el segundo número: "))
        print(f"Resultado: {num1 / num2}")
    elif opcion == "5":
        num = float(input("Introduce un número: "))
        print(f"Resultado: {math.sqrt(num)}")
    elif opcion == "6":
        base = float(input("Introduce la base: "))
        exponente = float(input("Introduce el exponente: "))
        print(f"Resultado: {base ** exponente}")
    elif opcion == "7":
        angulo = float(input("Introduce el ángulo en grados: "))
        radianes = math.radians(angulo)
        print(f"Coseno({angulo}°) = {math.cos(radianes):.4f}")
    elif opcion == "8":
        print("¡Hasta luego!")
    else:
        print("Opción no válida. Inténtalo de nuevo.")
