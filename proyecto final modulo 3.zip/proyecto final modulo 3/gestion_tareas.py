from nuevo import calculadora

# Lista para almacenar tareas
tareas = []

# Diccionario para almacenar datos de estudiantes (nombre, calificaciones, etc.)
estudiantes = {}

# Lista para almacenar contactos
contactos = []

# Función para agregar una tarea
def agregar_tarea():
    tarea = input("Introduce una nueva tarea: ")
    tareas.append(tarea)
    print("Tarea agregada con éxito.")

# Función para evaluar el rendimiento de un estudiante
def evaluar_estudiante():
    nombre = input("Introduce el nombre del estudiante: ")
    notas = []
    for i in range(5):
        nota = float(input(f"Introduce la nota {i+1}: "))
        notas.append(nota)
    
    promedio = sum(notas) / len(notas)
    print(f"Promedio de {nombre}: {promedio:.2f}")

    aprobadas = [nota for nota in notas if nota >= 4.0]
    reprobadas = [nota for nota in notas if nota < 4.0]
    print(f"Notas aprobadas: {', '.join(map(str, aprobadas))}")
    print(f"Notas reprobadas: {', '.join(map(str, reprobadas))}")

# Función para registrar un nuevo contacto
def agregar_contacto():
    nombre = input("Introduce el nombre del contacto: ")
    telefono = input("Introduce el número de teléfono del contacto: ")
    contactos.append((nombre, telefono))
    print("Contacto registrado con éxito.")


# Menú principal
while True:
    print("\n--- Menú ---")
    print("1. Agregar tarea")
    print("2. Evaluar rendimiento de estudiante")
    print("3. Registrar contacto")
    print("4. Calculadora avanzada")
    print("5. Salir")
    opcion = input("Selecciona una opción (1-5): ")

    if opcion == "1":
        agregar_tarea()
    elif opcion == "2":
        evaluar_estudiante()
    elif opcion == "3":
        agregar_contacto()
    elif opcion == "4":
        calculadora()
    elif opcion == "5":
        print("¡Hasta luego!")
        break
    else:
        print("Opción no válida. Inténtalo de nuevo.")
